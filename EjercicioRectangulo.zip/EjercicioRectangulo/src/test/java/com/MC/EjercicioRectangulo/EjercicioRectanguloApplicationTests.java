package com.MC.EjercicioRectangulo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjercicioRectanguloApplicationTests {

	@Test
	void contextLoads() {
	}

}
