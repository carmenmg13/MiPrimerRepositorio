package com.MC.EjercicioRectangulo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjercicioRectanguloApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjercicioRectanguloApplication.class, args);
	}

}
