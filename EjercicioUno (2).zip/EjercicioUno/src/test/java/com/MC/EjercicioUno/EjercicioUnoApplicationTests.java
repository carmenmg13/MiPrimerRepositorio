package com.MC.EjercicioUno;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjercicioUnoApplicationTests {

	@Test
	void contextLoads() {
	}

}
